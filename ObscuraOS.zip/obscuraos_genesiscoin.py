
import os
import random
import hashlib
import tkinter as tk
from tkinter import messagebox

# Simulated Wallet and GenesisCoin
class GenesisCoinSystem:
    def __init__(self):
        self.balance = round(random.uniform(1, 50), 3)
        self.wallet_address = self._generate_address()
        self.ledger_file = "genesiscoin_ledger.txt"
        self._write_ledger_entry("System boot - GenesisCoin minted")

    def _generate_address(self):
        return "GNC-" + hashlib.sha256(str(random.random()).encode()).hexdigest()[:20].upper()

    def _write_ledger_entry(self, entry):
        with open(self.ledger_file, "a") as f:
            f.write(f"{entry} | Balance: {self.balance} GNC\n")

    def mint(self):
        reward = round(random.uniform(0.5, 5.0), 3)
        self.balance += reward
        self._write_ledger_entry(f"Minted: {reward} GNC")

# GUI for ObscuraOS
class ObscuraOS(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ObscuraOS - GenesisCoin Edition")
        self.geometry("600x400")
        self.coin = GenesisCoinSystem()

        self._build_ui()

    def _build_ui(self):
        title = tk.Label(self, text="ObscuraOS | GenesisCoin Core", font=("Arial", 16, "bold"))
        title.pack(pady=10)

        self.info = tk.Label(self, text=self._wallet_info(), font=("Consolas", 10))
        self.info.pack(pady=10)

        mint_btn = tk.Button(self, text="Mint GenesisCoin", command=self._mint_coin)
        mint_btn.pack(pady=5)

        fake_gpu_btn = tk.Button(self, text="View Fake GPU", command=self._show_fake_gpu)
        fake_gpu_btn.pack(pady=5)

        fake_steam_btn = tk.Button(self, text="Launch ObscuraCore (Fake Steam)", command=self._fake_steam)
        fake_steam_btn.pack(pady=5)

    def _wallet_info(self):
        return f"Wallet Address: {self.coin.wallet_address}\nBalance: {self.coin.balance} GNC"

    def _mint_coin(self):
        self.coin.mint()
        self.info.config(text=self._wallet_info())
        messagebox.showinfo("Minted!", "You mined GenesisCoin out of thin air!")

    def _show_fake_gpu(self):
        messagebox.showinfo("ObscuraV1000", "Fake GPU Detected:\n1000GB VRAM\nCUDA 13.0\nSimulated Quantum Hashcore")

    def _fake_steam(self):
        messagebox.showinfo("ObscuraCore Launcher", "Launching apps...\nAI Painter\nAI Coder\nGNC Market Simulator\n... (all simulated)")

if __name__ == "__main__":
    app = ObscuraOS()
    app.mainloop()
