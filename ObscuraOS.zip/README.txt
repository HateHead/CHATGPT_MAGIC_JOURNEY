
ObscuraOS - GenesisCoin Edition
-------------------------------

This is a fantasy portable OS interface simulation created entirely in Python.
It includes:
- A fake 1000GB VRAM CUDA GPU
- An AI-powered OS terminal
- ObscuraCore (fake Steam-like App Hub)
- GenesisCoin: A currency minted from pure digital imagination

Run using:
1. Double-click `start.bat`
2. Or run `python obscuraos_genesiscoin.py` manually

This system is NOT connected to the blockchain. It's art. It's logic. It's yours.
